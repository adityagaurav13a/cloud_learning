package com.devops.app;

public class App {
    public static void main(String[] args) {
        System.out.println("Build Automation Using Maven Successful!");
    }
}

